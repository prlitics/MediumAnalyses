# TrumpRepublicanErosion
Dataset and Stata do file for my analysis on whether President Trump is responsible for the "eroding" Republican base.
